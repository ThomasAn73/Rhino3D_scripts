The toolbar buttons will work only when objects are *PRESELCTED*
(This is due to a limitation (or Design) in Rhinoscript)